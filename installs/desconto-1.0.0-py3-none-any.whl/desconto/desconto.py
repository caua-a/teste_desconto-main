def calcular_desconto(valor_total:int|float, percentual_desconto:int|float)-> float:
    """
        Calcula o valor líquido após a aplicação de um desconto percentual.

        Args:
            valor_total (int | float): O valor total do item ou serviço.
            percentual_desconto (int | float): O percentual a ser abatido (0 a 100).

        Returns:
            float: Valor calculado e arredondado para 2 casas decimais.

        Raises:
            TypeError: Se as entradas não forem numéricas.
            ValueError: Se as entradas forem logicamente inválidas para o contexto financeiro.
    """
    # 1. Validação de Tipo (Garante que são números)
    if not isinstance(valor_total, (int, float)) or isinstance(valor_total, bool):
        raise TypeError(f"Erro: O valor total e o desconto devem ser numéricos.")
    
    if not isinstance(percentual_desconto, (int, float)) or isinstance(percentual_desconto, bool):
        raise TypeError(f"Erro: O valor total e o desconto devem ser numéricos.")

    # 2. Validação de Lógica (Valores negativos ou impossíveis)
    if valor_total < 0:
        raise ValueError(f"Erro: O valor do produto não pode ser negativo.")
    
    if not (0 <= percentual_desconto <= 100):
        raise ValueError(f"Erro: O desconto deve estar entre 0 e 100.")

    # 3. Cálculo - ERRO: Soma em vez de subtrair
    desconto = valor_total * (percentual_desconto / 100)
    valor_final = valor_total + desconto  # ERRO DE LÓGICA: deveria ser -
    
    return round(valor_final, 2)
